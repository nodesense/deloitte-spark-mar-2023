package workshop.basics

object S006_Object extends  App {

  // object is a singleton instance
  // similar to Java Static classes
  // we can't create object of object
  // we can create objects for classes
  // no static keyword or similar stuff in Scala, we need to use object in of place static

  object Logger {
    var logLevel: Int = 0

    def info(msg: String) = println (msg)
  }

  Logger.logLevel = 2
  Logger.info("Starting application")

}
