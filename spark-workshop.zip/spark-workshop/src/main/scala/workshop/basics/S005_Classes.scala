package workshop.basics

object S005_Classes extends  App {

  class Product {
    // public is default
    // private only this class
    private var name: String = _; // empty string
    private var _price: Int = _; // assign 0

    // getter function
    def price = _price
    //setter function, price_= is a special function, decoded specially for = operator
    def price_= (newPrice:Int) = _price = newPrice


    // this class, child class and this package
    protected  var discount: Int = 0;
  }

  class Electronics extends  Product {
    def offer(value: Int) = discount = value;
  }

  val p1 = new Product() // iphone 10
  val p2 = new Product() // sansung galaxy, millions object created for each phone


  println("Price ", p1.price) //calls getter method
  p1.price = 100 // calls p1.price_= setter method
  // p1.price_= (200)
  println("Price ", p1.price) //calls getter method
}
