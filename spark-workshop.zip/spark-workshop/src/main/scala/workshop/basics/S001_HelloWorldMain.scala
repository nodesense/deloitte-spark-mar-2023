package workshop.basics
// Right click, context menu, run class name
// App is trait, has main function implemented
object S001_HelloWorldMain extends App {
  // we can write main function code/starter code for spark app
  println("Hello World")
  // command line arguments
  // semicolon is optional
  println("args", args.length)

  println(args)

  args.foreach(println)

  // mutable/immutable definition
  // immutable - constant - most preferred for data centric app
  // mutable - change/variable

  // val -immutable
  // var - mutable

  // Scala primitives are classes unlike Java primitives
  // When we compile our code, all primitives like Double, Int, Boolean etc
  // are converetd in to JRE native types
  val PI : Double = 3.14
  // PI = 3 // error
  var i: Int = 1
  i = 2

  // scala compiler can derive the type from expression
  // known as Type inference
  val PI2 = 3.14 // double

  println(PI, i)

  // since Scala primitives are classes, operator overloading supported on them

  // both below lines are exactly same
  i += 1
  i = i.+(2)   // + is a member  function of Int classes




}
