package workshop.basics

object S003_Functions extends  App {
  // val lambda_exp = (variable:Type) => Transformation_Expression

  // Java
  // Methods (def) are similar to Java Member functions (static, member function)
  // functions in scala is similar to lambda
  // functions are first class citizen meaning, it can be treated like object
  // functions can be passed as arg to another function,
  // functions can be returned as output from anotehr function

  // lambda expression/ aka function in Scala
  // returns types are implicits
  // val PI: Double = 3.14
  val add = (a: Int, b: Int ) => a + b
  val sub = (a: Int, b: Int ) => {
    a - b
  }

  println ( add(20, 10) ) // internally scala will write add.apply(20, 10)
  println ( sub(20, 10) )

  // functions are object, composablity, chaining, currying , higher order function...
   // apply is member function of object add (add is function object)
  println( add.apply(20, 10))

  val add2 = add

  println(add2(20, 10))
}
