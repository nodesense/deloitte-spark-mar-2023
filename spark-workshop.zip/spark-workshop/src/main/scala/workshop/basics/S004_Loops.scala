package workshop.basics

object S004_Loops extends App {
  // <- interator
  // to is a method of Int object, returns an Int Vector
  val list = for (i <- 1 to 5) yield i * 10; // yield is expression

  println("Vector ", list)

  def multi(n: Int): Int = {
    println("multi called ", n)
    n * n
  };

  val list2 = for (i <- 1 to 5) yield multi(i);


  val list3 = for (i <- 1 to 5; j <- 1 until i) yield (i, j)
  println("Vector pair ", list3);


  val nums = Seq(1, 2, 3)
  val letters = Seq('a', 'b', 'c')
  val res = for {
    n <- nums
    c <- letters
  } yield (n, c)

  println("Result ", res);
}
