package workshop

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._
import org.apache.spark.storage.StorageLevel // import all

object S007_MovieLensAnalyticsFinal extends  App {

  val MoviesPath = "/home/training/Downloads/ml-latest-small/movies.csv"
  val RatingsPath = "/home/training/Downloads/ml-latest-small/ratings.csv"

  // SparkSession is entry point for spark SQL, DF are same
  val spark: SparkSession  = SparkSession
    .builder()
    //.master("local") // spark run inside hello world app
    .master("spark://65.109.134.95:7077") // now driver runs the tasks on cluster
    .appName("MovieLensAnalytics")
    // .config("spark.cores.max", "48") // MAX CORE Across Cluster
    //.config("spark.executor.memory", "4g")
    .getOrCreate()

  spark.sparkContext.setLogLevel("WARN")
  import spark.implicits._
  // movie schema
  val MovieSchema = StructType(
    List(
      StructField("movieId", IntegerType, true), // true means nullable
      StructField("title", StringType, true),
      StructField("genres", StringType, true)
    )
  )

  val RatingSchema = StructType(
    List(
      StructField("userId", IntegerType, true),
      StructField("movieId", IntegerType, true),
      StructField("rating", DoubleType, true),
      StructField("timestamp", LongType, true)
    )
  )

  // Spark SQL
  // spark is SparkSession
  // we no need to use inferSchema
  // spark.read is for Batch data handling, data lake, databases, datawarehouse, files
  //spark.readStream is for streaming data handling kafka, rabbitmq etc
  //data frame is immutable
  // every data frame has hdd internally, use RDD partition, RDD task, DAG etc
  val movieDf = spark.read
    .format("csv")
    .option("header",  true) // csv has the header, so skip the first line
    .option("delimitter", ",")
    .schema(MovieSchema) // use the Schema
    .load(MoviesPath)


//
//  // we no need to use inferSchema
  val ratingDf = spark.read
    .format("csv")
    .option("header",  true)
    .option("delimitter", ",")
    .schema(RatingSchema) // use the Schema
    .load(RatingsPath)
//



//
//
//  // get most popular movies
//  // avg rating per movie id,
//  // count number of users voted for that movie
//  // and filter total ratings >= 100 and avg_rating > 3
//  // avg("rating") creates a column named  avg(rating)
//  // count("userId") creates a column named  count(userId)
//
  val popularMovies = ratingDf
    .groupBy($"movieId")
    .agg(avg("rating").alias("avg_rating"), count("userId"))
    .withColumnRenamed("count(userId)", "total_rating")
  .sort(desc("avg_rating"))
  .filter( ($"total_rating" >= 100 ) && ($"avg_rating" >= 4 ))

  popularMovies.cache()
//
//
//  // if your dataframe has 15 columns, you may use only 2 columns for joins
    val slimMovieDf = movieDf.select("movieId", "title")
//
//  // the data is readily avaialbel in all the workers where executors running
//  // all small tables, master/dimension tables can be broadcasted
    val broadcatedMovieDf = broadcast(slimMovieDf)

  val mostPopularMoviesList = popularMovies.join(slimMovieDf, popularMovies("movieId") === movieDf("movieId"))
    .select(popularMovies("movieId"), $"title", $"avg_rating", $"total_rating" )
//

  // mostPopularMoviesList.cache() // to store result in csv json etc
  mostPopularMoviesList.persist(StorageLevel.DISK_ONLY)
  mostPopularMoviesList.printSchema()
  mostPopularMoviesList.show()


  println("mostPopularMoviesList plans")
  println(mostPopularMoviesList.explain(true))

  println("press enter to exit")
  scala.io.StdIn.readLine()
}