package workshop

import org.apache.spark.sql.SparkSession

object S005_Glom extends  App {

  val spark: SparkSession  = SparkSession
    .builder()
    .master("local") // spark run inside hello world app
    //.master("spark://192.168.1.110:7077") // now driver runs the tasks on cluster
    .appName("Cache")
    .getOrCreate()

  val sc = spark.sparkContext
  sc.setLogLevel("WARN")

  // creation of input rdd
  val rdd = sc.parallelize( 1 to 100)

  val rdd2 = rdd.repartition(4)

  // collect(), action method, collect data from    all partitions , bring back to driver
  // BAD Approach, performance, driver memory should be capable enough to handle all the load

  val data = rdd2.collect()
  println("All data ", data.toList)

  // take will pick the data from first partition onwards, if the first partitions has all requested numbers, it picks from first partition
  // good for sampling, print, interactive coding
  val data2 = rdd2.take(4)
  println("take data, ", data2.toList)

  // collect the data from each partition, doesn't merge
  // driver needs memory
  // NOT A GOOD for large data
  //data3 array of array, NOT RDD
  val data3 = rdd2.glom()
  println("glom data, ", data3)
  data3.foreach(list => {
    println("------------------------------")
    println(list.toList)
  })

  // iterate over all the values
  // action method, foreach runs inside executor, on each partition
  // for every element in partition, foreach is called
  // does not collect data to driver
  // assume 4 partitions, each partitions has 1000 records, foreach function called for 4000 times
//  rdd2.foreach( n => {
//    println("FE " + n)
//  })

  println()


  // foreachparitions, action function
  //used to custom process the data , like weriting the parittion dato destination which is not supported by spark
    // foreach function exeucte inside executor
  // foreach doesnot collect data back to driver
  // for each partition, the function is invoked, we can store the data to db, implement custom data sink
  // assume 4 partitions, each partitions has 1000 records, foreachPartition function called for 4 times
  rdd2.foreachPartition( partitionData => {
    // sorting here will use scala collection functions, not native spark
    // native spark -- cluster to sort
    // scala collection - runs on single jvm
    println("foreachPartition called")
    partitionData.foreach(println)  // print the numbers
  })

  println("press enter to exit")
  scala.io.StdIn.readLine()
}