
open the terminal

pip install findspark

pip install jupyterlab

jupyter lab 

Check the url printed on  console with token, open the url in the browser


open terminal

cd pyexamples

# local master

python analytics.py


spark-submit --master spark://65.109.134.95:7077 analytics.py


spark-submit --master spark://65.109.134.95:7077 analytics.py
spark-submit --master spark://65.109.134.95:7077 --executor-memory 2g analytics.py

spark-submit --master spark://65.109.134.95:7077 --executor-memory 2g  --executor-cores 2 analytics.py


spark-submit --master spark://65.109.134.95:7077 --executor-memory 2g --driver-memory 4g analytics.py


spark-submit --master spark://65.109.134.95:7077 --executor-memory 2g --driver-memory 4g --num-executors 1 --conf spark.executor.instances=1 analytics.py

