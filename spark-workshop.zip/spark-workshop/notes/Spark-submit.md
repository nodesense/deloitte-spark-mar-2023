on sbt shell


compile 
package 


in the terminal

spark-submit --class workshop.S008_MovieLensAnalyticsSQL --master spark://65.109.134.95:7077 /home/training/spark-workshop/target/scala-2.12/spark-workshop_2.12-0.1.0-SNAPSHOT.jar