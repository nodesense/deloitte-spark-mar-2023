$SPARK_HOME/bin/spark-class org.apache.spark.deploy.master.Master

You have to copy IP address and port from spark master ui

spark://65.109.134.95:7077 , this port 7077 is RPC port, internal to spark master and worker and driver

to use in browser
http://65.109.134.95:8080    Spark Master Web UI for troubleshooting, user friendly ui for cluster

Run this command after coping the right IP address, paste at the end of command

Run Worker 1
terminal
Each worker has a Web UI, port is dynamically incremental, starting 8081

$SPARK_HOME/bin/spark-class org.apache.spark.deploy.worker.Worker spark://65.109.134.95:7077

http://65.109.134.95:8081



Run Worker 2
open new terminal
Each worker has a Web UI, port is dynamically incremental, starting 8081

$SPARK_HOME/bin/spark-class org.apache.spark.deploy.worker.Worker spark://65.109.134.95:7077

http://65.109.134.95:8082

=============